package org.testng.internal.annotations;

/**
 * For backward compatibility.
 */
public interface IAnnotationTransformer extends org.testng.IAnnotationTransformer {

}
