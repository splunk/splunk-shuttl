package test.abstractmethods;

public class CRUDTest2 extends CRUDTest {

  @Override
  public void create() {
  }

  @Override
  public void read() {
  }

}
